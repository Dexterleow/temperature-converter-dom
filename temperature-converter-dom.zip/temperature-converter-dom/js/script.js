document.addEventListener("DOMContentLoaded", function(event) {
  console.log("HelloWorld");

    function processForm () {
    console.log("button clicked");
    var temperature = Number(document.tempForm.temp.value);

    var tempType = "";
    for (var i=0; i < document.tempForm.choice.length; i++) {
      if (document.tempForm.choice[i].checked) {
        tempType = document.tempForm.choice[i].value;
      }
      // console.log(tempType);
      // console.log("tempType test");
    }

    console.log("temp:",temperature);
    var result = 0;
    if (tempType == 'fahrenheit') {
      console.log("from F to C");
      result = temperature * 9/5 + 32;

    } else {
      console.log("from C to F");
      result = (temperature -  32)  *  5/9;
    }

    console.log(result);
    console.log(document.getElementById("output"));
    document.getElementById("output").value = result;
    console.log("getElementsbyId Output test");
  }

  processForm();

  function clearForm(){

  }
  // Assign the result field value here
  // document.tempForm.resultField.value = result;
  // document.getElementById("output").value = result;
  document.getElementById("convert").addEventListener("click", processForm);
  document.getElementById("clear").addEventListener("click", processForm);


  // document.getElementById("demo").innerHTML = "Paragraph changed!";
  console.log("DOM fully loaded and parsed");
});
